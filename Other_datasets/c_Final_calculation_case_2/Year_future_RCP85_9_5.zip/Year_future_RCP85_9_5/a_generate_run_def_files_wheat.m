%%
clear all;clc
%load('Maize_data.mat')
%load('Wheat_data.mat')

maize_data = csvread('maize_planting_date_no_NA.csv',1,0);
Seq=maize_data(:,1);
lat=maize_data(:,2);
lon=maize_data(:,3);
planting_year=maize_data(:,4);
planting_day=maize_data(:,5);

wheat_data = csvread('wheat_planting_date_no_NA.csv',1,0);
Seq=wheat_data(:,1);
Lat=wheat_data(:,2);
Lon=wheat_data(:,3);
Planting_day=wheat_data(:,4);
Planting_day_in_previous_year=wheat_data(:,5);


planting_day=round(planting_day,0);
Planting_day=round(Planting_day,0);
Planting_day_in_previous_year=round(Planting_day_in_previous_year,0);

%maize_harvesting_day_in_this_year=round(maize_harvesting_day_in_this_year,0);


%maize_harvesting_day=round(maize_harvesting_day,0);
%max(Planting_day)>31+28+31+30+31+30+31+31+30+31+30

%%

% run.def
% read run.def.txt file to a cell file
n=length(lat)
for k = 1:n
    if(Planting_day_in_previous_year(k)<349)

    % run.def
    fid = fopen('run.def.txt','r');
    i = 1;
    tline = fgetl(fid);
    A{i} = tline;
    while ischar(tline)
        i = i+1;
        tline = fgetl(fid);
        A{i} = tline;
    end
    fclose(fid);


% each index in the cell file is the line number


    A{20} = ['LIMIT_WEST = ',num2str(round(lon(k),1)-0.5)];
    A{21} = ['LIMIT_EAST = ',num2str(round(lon(k),1)+0.5)];
    A{22} = ['LIMIT_SOUTH= ',num2str(round(lat(k),1)-0.5)];
    A{23} = ['LIMIT_NORTH= ',num2str(round(lat(k),1)+0.5)];
    
    A{387} =['SP_IPLT0=0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  120, ',num2str(Planting_day(k)),',',num2str(planting_day(k)),',284'];
    
        if(Planting_day(k)<349)
            A{391} =['SP_MAXGS=0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  350, ',num2str(365-Planting_day_in_previous_year(k)+planting_day(k)-14),',',num2str(350),',350'];
        else
            A{391} =['SP_MAXGS=0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  350, ',num2str(365-Planting_day_in_previous_year(k)+planting_day(k)-14),',',num2str(Planting_day(k)-planting_day(k)-14),',350'];
        end


    % Write cell A into txt run.def
    nam=['run',num2str(k),'.def.txt'];
    
    fid = fopen(nam, 'w');



    for i = 1:numel(A)
        if A{i+1} == -1
            fprintf(fid,'%s', A{i});
            break
        else
            fprintf(fid,'%s\n', A{i});
        end
    end
    
        fclose(fid);
    
    
    
    
    
    end
    
end

%=% config.card
% read run.def.txt file to a cell file
    n=length(lat);
for k = 1:n
    if(Planting_day_in_previous_year(k)<349)
    % config.card
    fid = fopen('config.card.restart.txt','r');
    i = 1;
    tline = fgetl(fid);
    A{i} = tline;
    while ischar(tline)
        i = i+1;
        tline = fgetl(fid);
        A{i} = tline;
    end
    fclose(fid);


% each index in the cell file is the line number


    A{14} = ['JobName=Pixel-',num2str(k)];
    
    A{28} =['DateBegin=',num2str(planting_year(k)),'-01-01'];
    A{29} =['DateEnd=',num2str(planting_year(k)+1),'-12-31'];

    A{106} = ['RestartJobName=Pixel-',num2str(k)];
    A{121} = ['RestartJobName=Pixel-',num2str(k)];

    % Write cell A into txt run.def
    nam=['config.card.',num2str(k),'.txt'];
    
    fid = fopen(nam, 'w');



    for i = 1:numel(A)
        if A{i+1} == -1
            fprintf(fid,'%s', A{i});
            break
        else
            fprintf(fid,'%s\n', A{i});
        end
    end
    
    
    
    
    
    fclose(fid);
    
    
    
    end
end


%%

% run.def
% read run.def.txt file to a cell file
n=length(lat)
for k = 1:n
if(Planting_day_in_previous_year(k)>=349)
% run.def
fid = fopen('run.def.txt','r');
i = 1;
tline = fgetl(fid);
A{i} = tline;
while ischar(tline)
    i = i+1;
    tline = fgetl(fid);
    A{i} = tline;
end
fclose(fid);


% each index in the cell file is the line number


    A{20} = ['LIMIT_WEST = ',num2str(round(lon(k),1)-0.5)];
    A{21} = ['LIMIT_EAST = ',num2str(round(lon(k),1)+0.5)];
    A{22} = ['LIMIT_SOUTH= ',num2str(round(lat(k),1)-0.5)];
    A{23} = ['LIMIT_NORTH= ',num2str(round(lat(k),1)+0.5)];
    
    A{387} =['SP_IPLT0=0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  120, ',num2str(Planting_day(k)),',',num2str(planting_day(k)),',284'];
if(Planting_day(k)<349)
    A{391} =['SP_MAXGS=0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  350, ',num2str(350),',',num2str(Planting_day(k)-planting_day(k)-14),',350'];
else
    A{391} =['SP_MAXGS=0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  350, ',num2str(350),',',num2str(Planting_day(k)-planting_day(k)-14),',350'];
end


    % Write cell A into txt run.def
    nam=['run',num2str(k),'.def.txt'];
    
    fid = fopen(nam, 'w');



    for i = 1:numel(A)
        if A{i+1} == -1
            fprintf(fid,'%s', A{i});
            break
        else
            fprintf(fid,'%s\n', A{i});
        end
    end
    
    fclose(fid);
    
    
    
    
    
end 
    
end

% config.card
% read run.def.txt file to a cell file
n=length(lat);
for k = 1:n
if(Planting_day_in_previous_year(k)>=349)
% config.card
fid = fopen('config.card.txt','r');
i = 1;
tline = fgetl(fid);
A{i} = tline;
while ischar(tline)
    i = i+1;
    tline = fgetl(fid);
    A{i} = tline;
end
fclose(fid);


% each index in the cell file is the line number


    A{14} = ['JobName=Pixel-',num2str(k)];
    
    A{28} =['DateBegin=',num2str(planting_year(k)),'-01-01'];
    A{29} =['DateEnd=',num2str(planting_year(k)+1),'-12-31'];


    % Write cell A into txt run.def
    nam=['config.card.',num2str(k),'.txt'];
    
    fid = fopen(nam, 'w');



    for i = 1:numel(A)
        if A{i+1} == -1
            fprintf(fid,'%s', A{i});
            break
        else
            fprintf(fid,'%s\n', A{i});
        end
    end
    
    
    
    
    
    fclose(fid);
    
    
    
end

end


